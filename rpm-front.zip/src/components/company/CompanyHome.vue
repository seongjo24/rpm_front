<template>
<div id =tempNav>

<router-view></router-view>
</div>
</template>
<style>
    #tempNav{
        padding-top: 50px;

    }


</style>