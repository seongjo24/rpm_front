<template>
    <div>
        <link rel="stylesheet" type="text/css" href="/css/ladda-themeless.min.css">
        <link rel="stylesheet" type="text/css" href="/css/normalize.css">
        <link rel="stylesheet" type="text/css" href="/css/qbkl-grid.css">
        <link rel="stylesheet" type="text/css" href="/css/style-ko.css">
        <link rel="stylesheet" type="text/css" href="/css/font-awesome.min.css">
        <div class="top-decorations">
            <a href="" style="
				position: absolute;
				left: 15px;
				top: 20px;
				text-decoration: none;
				color: #ffffff;
			"></a>
        </div>
    <section id="intro" class="fx-backstretch">
        <div class="info" style="position: relative; z-index: 0; background: none;">
            <div class="container" style="top: 357.5px;">
                <div class="row">
                    <div class="col-full"><h1>{{name}}</h1></div>
                </div>
                <div class="row"><div class="col-1-4 centered line"></div></div>
                <div class="row">
                    <div class="col-full"><h4>소프트웨어 엔지니어</h4></div>
                </div>
            </div>
            <div class="backstretch" style="left: 0px; top: 0px; overflow: hidden; margin: 0px; padding: 0px; height: 888px; width: 1903px; z-index: -999998; position: absolute;"><img id="profile_img" src="/img/backstretch.jpg" style="position: absolute; margin: 0px; padding: 0px; border: none; width: 1903px; height: 1070.44px; max-height: none; max-width: none; z-index: -999999; left: 0px; top: -91.2188px;"></div></div>
        <div id="nav-sticky-wrapper" :class=sticky style="height: 60px;"><nav id="nav" :style=fix>
            <ul class="clearfix">
                <li v-for="(navi,index) of navis" @click="tabSwitch(index)" :key="navi.id" :class={current:navi.switch}><a :href=navi.id>{{navi.title}}</a></li>

            </ul>
        </nav></div>
    </section>
    <section id="aboutme" class="section">
        <div class="container">
            <div class="row">
                <div class="col-full">
                    <h2 class="section-title">introdution</h2>
                    <div class="centered line"></div>
                </div>
            </div>

            <div class="row section-content">
                <div class="col-1-2" style="text-align: center;">
                    <img alt="접니다!" style="max-width: none !important; height: 444px;" src="/img/profile_pic.jpg">
                </div>
                <div class="col-1-2">
                  <h4>안녕하세요 원종석입니다!</h4><br>
                    <p>저의 웹사이트를 방문해 주셔서 감사합니다!</p>
             <!--       <ul><li>영어 공부하는 것이 제일 즐거워요.</li><li>좋아하는 e스포츠 경기를 봐요.</li><li>전 세계 컨퍼런스에서 영감을 받고 있어요.</li>
                        <li>그리고, 더 많은 사람들 만나 새로운 기회를 창출하고 있어요.</li>
                    </ul>-->
                </div>
            </div>
        </div>
    </section>

    <section id="skills" class="section-alt">
        <div class="container">
            <div class="row">
                <div class="col-full">
                    <h2 class="section-title">Skill</h2>
                    <div class="centered line"></div>
                </div>
            </div>

            <div class="row section-content">
                <div class="skill-container">
                  <div class="col-full skill-container">
                    <h3 style="font-weight: bold !important;">Programming Language</h3>
                  </div>

                    <div v-for="language of languages" :key="language" class="col-1-5 skill">
                        <h4 style="color: #001F41 !important;font-weight: bold !important;">{{language}}</h4>
                    </div><br><br><br><br>

                </div>
              <div class="col-full skill-container">
                <h3 style="font-weight: bold !important;"><br><br><br><br><br></h3>
              </div>
              <div class="col-full skill-container">
                <h3 style="font-weight: bold !important;">Usage</h3>
              </div>
                <br>
                <div class="col-2-3 col-wrap centered skill-container">

                    <div class="col-1-3" style="text-align: center !important;">
                        <h4 style="font-weight: bold !important;">프레임워크</h4><br>
                        <ul><li v-for="framework of frameworks" :key="framework">{{framework}}</li></ul>
                    </div>
                    <div class="col-1-3" style="text-align: center !important;">
                        <h4 style="font-weight: bold !important;">소프트웨어</h4><br>
                        <ul><li v-for="software of softWares" :key="software">{{software}}</li></ul>
                    </div>
                    <div class="col-1-3" style="text-align: center !important;">
                      <h4 style="font-weight: bold !important;">데이터베이스</h4><br>
                      <ul><li v-for="database of databases" :key="database">{{database}}</li></ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!--<section id="education" class="section-alt">
        <div class="container">
            <div class="row">
                <div class="col-full">
                    <h2 class="section-title">education</h2>
                    <div class="centered line"></div>
                </div>
            </div>

            <div class="row section-content">
                <div v-for="education of educations" :key="education.name"  class="row school">
                    <div class="col-full">
                        <h3>{{education.name}}</h3>
                        <div class="school-meta">{{education.major}}</div>
                    </div>

                    <div class="col-full text-center">
                        {{education.content}}
                        <p><strong>{{education.date}}</strong>
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </section>-->

    <section id="portfolio" class="section">
        <div class="container">
            <div class="row">
                <div class="col-full">
                    <h2 class="section-title">project</h2>
                    <div class="centered line"></div>
                </div>
            </div>
                    <router-link to="/home" title="RPM"><img src="@/assets/image/rpmlogoblack.png" alt="RPM"></router-link>
            </div>
    </section>

    <section id="contact" class="section">
        <div class="container">
            <div class="row">
                <div class="col-full">
                    <h2 class="section-title">contact</h2>
                    <div class="centered line"></div>
                </div>
            </div>

            <div class="row section-content">
                <div class="col-2-3 col-wrap centered text-center">
                    <div class="row">
                        <div class="col-full" style="margin-bottom: 25px;">
                            함께 일하고 싶으시거나 <br>연락을 원하신다면 아래로 연락 주세요!! <br> pn : {{pn}} <br>e-mail : {{email}} <br><a style="padding-left: 0px !important;" href="https://github.com/h32109">{{github}}</a>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>


    </div>


</template>

<script>
    export default {
        name: "Profile",
        data(){
            return {
                name: '원종석',
                email:'h32109@gmail.com',
                pn:'010-5051-0997',
                github : 'https://github.com/h32109',
                navis: [
                    {title: 'INTRODUTION', id: '#aboutme',switch:false}, {title: 'SKILL', id: '#skills',switch:false}, /*{title: 'EDUCATION', id: '#education',switch:false},*/
                    {title: 'PROJECT', id: '#portfolio',switch:false}, {title: 'CONTACT', id: '#contact',switch:false}
                    ],
                fix:'',
                sticky:'',
                languages:['modern java','javascript','python','ANSI-SQL','html'],
                frameworks:['Spring 4/5','Spring boot','Spring Security', 'Spring batch', '전자정부','Vue3.0','Hibernate', 'Docker'],
                databases : ['mariadb', 'mySQL', 'Oracle'],
                softWares:['windows','mysql','git','IntelliJ', 'Pycharm', 'STS4','ANDROID STUDIO'],
/*                educations:[{name:'bit camp',major:'java기반 웹&앱 개발자 양성과정',content:'java 공부 했음',date:'2019.08~2020.02'}]*/
            }
            },
        methods: {
            tabSwitch(i){
                this.navis[i].switch = true
                for (let a = 0; a < this.navis.length; a++) {
                    if (a != i) {
                        this.navis[a].switch = false
                    }
                }


            },
            handleScroll() {
               // console.log(scrollY)

                if (scrollY < 155) {
                    this.sticky = 'sticky-wrapper'
                    this.fix = 'z-index: 100; '
                } else {
                    this.sticky = 'sticky-wrapper is-sticky'
                    this.fix = 'z-index: 100; position: fixed; top: 10px;'
                }
                if(0<scrollY && scrollY<900){
                    this.tabSwitch(0)
                }else if(900<=scrollY && scrollY<1598){
                    this.tabSwitch(1)
                }else if(1598<=scrollY && scrollY<2236){
                    this.tabSwitch(2)
                }else if(2236<=scrollY&& scrollY<2498){
                    this.tabSwitch(3)
                }else if(2498<=scrollY){
                    this.tabSwitch(4)
                }
            },


        },
            created() {
                window.addEventListener('scroll', this.handleScroll);
            },
            destroyed() {
                window.removeEventListener('scroll', this.handleScroll);
            }
        }

</script>

<style scoped>
    .container a{
       padding-left: 150px;
    }
    #portfolio{
        padding: 300px;
    }
    #contact{
        padding: 300px;
    }
    .col-1-2 {
      text-align: center !important;
    }
    #profile_img {
      max-width: 100% !important;
      max-height: 100% !important;
    }
    #nav ul li a {
      padding: 0px 45px 0px 45px !important;
    }


</style>
